#=======================================================================
# Simple latitude-longitude smooth, shaded, contour plot
#
# Copyright (c) 2003 by Johnny Lin.  For licensing, distribution
# conditions, contact information, and additional documentation see
# the URL http://www.johnny-lin.com/pylib.html#license.
#=======================================================================


#- Import modules:

import Numeric as N
#import cdms, vcs


#- Make dimensions and data:

lat = 22
lon = 88
data = N.outerproduct(N.sin(lat*N.pi/360.), N.cos(lon*N.pi/360.))

print data


#- Make plot:

#v = vcs.init()
#lonAxis = cdms.createAxis(lon)
#latAxis = cdms.createAxis(lat)
#v.isofill(data, xaxis=lonAxis, yaxis=latAxis, continents=1, name="Example")


##- Write out Postscript and GIF versions of plot:

#v.postscript('eg.ps','l')
#v.gif('eg.gif','r')


#====== end of file ======

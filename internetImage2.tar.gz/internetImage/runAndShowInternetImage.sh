#!/bin/sh

python internetImage.py
gnome-open CityEdges2_2007.csv.png

#!/usr/bin/python

import Image
import ImageDraw

SAVE_SCALE = 10
SCALE = 50

CONNECTION_FILL_R = 255
CONNECTION_FILL_G = 255
CONNECTION_FILL_B = 255
CONNECTION_FILL_A = 255
COUNTRY_BORDERS = 'countryborders.txt'
COUNTRY_BORDERS_BOLDNESS = 3;
COUNTRY_FILL_R = 0
COUNTRY_FILL_G = 255
COUNTRY_FILL_B = 0
COUNTRY_FILL_A = 255
DATA_FILE = 'CityEdges2_2007.csv'
DELTA = [180, 80] #Longitude, Latitude
DOUBLE_SPLIT = False
IMAGE_SIZE = [DELTA[0] * 2 * SCALE, DELTA[1] * 2 * SCALE]
NUMBER_OF_IPS_THRESHOLD = 0
SACE_IMAGE_SIZE = [DELTA[0] * 2 * SAVE_SCALE, DELTA[1] * 2 * SAVE_SCALE]

[SOURCE_LATITUDE_INDEX, SOURCE_LONGITUDE_INDEX, DEST_LATITUDE_INDEX, DEST_LONGITUDE_INDEX, NUMBER_OF_IPS_INDEX] = [4, 5, 6, 7, 10]
[BORDER_LONGITUDE_INDEX, BORDER_LATITUDE_INDEX] = (2, 3)

def draw_connection(draw, coordinates, allow_split = True, r = CONNECTION_FILL_R, g = CONNECTION_FILL_G, b = CONNECTION_FILL_B, a = CONNECTION_FILL_A):
    source_longitude = coordinates[0]
    source_latitude = coordinates[1]
    dest_longitude = coordinates[2]
    dest_latitude = coordinates[3]

    # Allow connections to go around the world
    if allow_split:
        if abs(source_longitude - dest_longitude) > IMAGE_SIZE[0] / 2:
            if source_longitude < dest_longitude:
                draw_connection_split_longitude(draw, source_longitude, source_latitude, dest_longitude, dest_latitude)
            else:
                draw_connection_split_longitude(draw, dest_longitude, dest_latitude, source_longitude, source_latitude)
            return
        if abs(source_latitude - dest_latitude) > IMAGE_SIZE[1] / 2:
            if source_latitude < dest_latitude:
                draw_connection_split_latitude(draw, source_longitude, source_latitude, dest_longitude, dest_latitude)
            else:
                draw_connection_split_latitude(draw, dest_longitude, dest_latitude, source_longitude, source_latitude)
            return

    draw.line(coordinates, fill=(r,g,b,a))
    #draw.arc(coordinates, 0, 20, CONNECTION_FILL_=(CONNECTION_FILL_R,CONNECTION_FILL_G,CONNECTION_FILL_B))

def draw_connection_split_latitude(draw, start_longitude, start_latitude, end_longitude, end_latitude):
    midpoint = get_midpoint(start_latitude, start_longitude, end_latitude, end_longitude, IMAGE_SIZE[1])

    draw_connection(draw, (midpoint, 0,             start_longitude, start_latitude), allow_split = DOUBLE_SPLIT)
    draw_connection(draw, (midpoint, IMAGE_SIZE[1], end_longitude,   end_latitude),   allow_split = DOUBLE_SPLIT)

def draw_connection_split_longitude(draw, start_longitude, start_latitude, end_longitude, end_latitude):
    midpoint = get_midpoint(start_longitude, start_latitude, end_longitude, end_latitude, IMAGE_SIZE[0])

    draw_connection(draw, (0, midpoint,             start_longitude, start_latitude), allow_split = DOUBLE_SPLIT)
    draw_connection(draw, (IMAGE_SIZE[0], midpoint, end_longitude,   end_latitude),   allow_split = DOUBLE_SPLIT)

def draw_point(draw, coordinates, allow_split = True, r = COUNTRY_FILL_R, g = COUNTRY_FILL_G, b = COUNTRY_FILL_B, a = COUNTRY_FILL_A):
    point_longitude = coordinates[0]
    point_latitude = coordinates[1]
    for ii in range(-COUNTRY_BORDERS_BOLDNESS, COUNTRY_BORDERS_BOLDNESS):
        coordinates = (point_longitude + ii,
                       point_latitude - COUNTRY_BORDERS_BOLDNESS,
                       point_longitude + ii,
                       point_latitude + COUNTRY_BORDERS_BOLDNESS
                      )
        draw_connection(draw, coordinates, r = r, g = g, b = b, a = a)

def fix_country_names(string):
    string = string.replace('Korea, Republic of', 'Korea Republic of')
    string = string.replace('Iran, Islamic Republic of', 'Iran Islamic Republic of')
    string = string.replace('Virgin Islands, U.S.', 'Virgin Islands U.S.')
    string = string.replace('Tanzania, United Republic of', 'Tanzania United Republic of')
    string = string.replace('Virgin Islands, British', 'Virgin Islands British')
    string = string.replace('Moldova, Republic of', 'Moldova Republic of')
    string = string.replace('Palestinian Territory, Occupied', 'Palestinian Territory Occupied')
    string = string.replace('Congo, The Democratic Republic of the', 'Congo The Democratic Republic of the')
    string = string.replace('Micronesia, Federated States of', 'Micronesia Federated States of')

    return string

def get_midpoint(start_longitude, start_latitude, end_longitude, end_latitude, image_size):
    start_edge_length = start_longitude
    end_edge_length = image_size - end_longitude
    longitude_length = start_edge_length + end_edge_length
    start_edge_length_percent = start_edge_length * 1.0 / longitude_length
    end_edge_length_percent = end_edge_length * 1.0 / longitude_length
    latitude_length = abs(start_latitude - end_latitude)

    return (latitude_length * start_edge_length_percent) + min(start_latitude, end_latitude)

def longitude_to_cartesian(x):
    return (x + DELTA[0]) * SCALE

def latitude_to_cartesian(x):
    return IMAGE_SIZE[1] - ((x +  DELTA[1]) * SCALE)

def main_borders(im):
    # Load Data
    file = open(COUNTRY_BORDERS, 'r')
    data = file.readlines()
    file.close();

    line = 1;
    draw = ImageDraw.Draw(im)

    for ii in data:
        ii_split =  fix_country_names(ii).split(',')
        border_longitude = float(ii_split[BORDER_LONGITUDE_INDEX])
        border_latitude = float(ii_split[BORDER_LATITUDE_INDEX])
        coordinates = (longitude_to_cartesian(border_longitude),
                       latitude_to_cartesian(border_latitude))
        draw_point(draw, coordinates)
def main_connections(im):
    # Load Data
    file = open(DATA_FILE, 'r')
    data = file.readlines()
    file.close();

    data_map = {}
    line = 1;

    # Analyse Data
    for ii in data:
        ii_split =  fix_country_names(ii).split(',')
        source_longitude = int(ii_split[SOURCE_LONGITUDE_INDEX])
        source_latitude = int(ii_split[SOURCE_LATITUDE_INDEX])
        dest_longitude = int(ii_split[DEST_LONGITUDE_INDEX])
        dest_latitude = int(ii_split[DEST_LATITUDE_INDEX])
        number_of_ips = int(ii_split[NUMBER_OF_IPS_INDEX])
        if source_longitude != 10000 and source_latitude != 10000 and dest_longitude != 10000 and dest_latitude != 10000:
            coordinates = (longitude_to_cartesian(source_longitude),
                           latitude_to_cartesian(source_latitude),
                           longitude_to_cartesian(dest_longitude),
                           latitude_to_cartesian(dest_latitude)
                          )
            if number_of_ips > NUMBER_OF_IPS_THRESHOLD:
                if coordinates in data_map:
                    data_map[coordinates] = data_map[coordinates] + number_of_ips
                else:
                    data_map[coordinates] = number_of_ips

        line = line + 1;

    draw = ImageDraw.Draw(im)

    # Draw Data
    for ii in data_map:
        print str(ii) + '\t' + str(data_map[ii])
        draw_connection(draw, ii)

def main():
    im = Image.new('RGBA', IMAGE_SIZE)

    main_borders(im)
    main_connections(im)

    # Resize Image
    im = im.resize(SACE_IMAGE_SIZE, Image.ANTIALIAS)

    # Save Image
    file = open(DATA_FILE + '.png', 'w')
    im.save(file)
    file.close()

if __name__ == '__main__':
  main()
